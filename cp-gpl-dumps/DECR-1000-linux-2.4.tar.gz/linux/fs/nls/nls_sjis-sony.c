/*
 * linux/fs/nls_sjis-sony.c
 * Based upon linux/fs/nls_sjis.c
 * Copyright 2003 Sony Corporation
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/string.h>
#include <linux/nls.h>
#include <linux/errno.h>

static struct nls_table *p_nls;

static struct nls_table table = {
	"sjis-sony",
	NULL,
	NULL,
	NULL,
	NULL,
	THIS_MODULE,
};

static int __init init_nls_sjis_sony(void)
{
	p_nls = load_nls("cp932-sony");

	if (p_nls) {
		table.uni2char = p_nls->uni2char;
		table.char2uni = p_nls->char2uni;
		table.charset2upper = p_nls->charset2upper;
		table.charset2lower = p_nls->charset2lower;
		return register_nls(&table);
	}

	return -EINVAL;
}

static void __exit exit_nls_sjis_sony(void)
{
	unregister_nls(&table);
	unload_nls(p_nls);
}

module_init(init_nls_sjis_sony)
module_exit(exit_nls_sjis_sony)
MODULE_LICENSE("Dual BSD/GPL");
